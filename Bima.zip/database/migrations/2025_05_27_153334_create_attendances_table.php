<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('attendances', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('id_user');
            $table->foreign('id_user')->references('id')->on('users')->onDelete('cascade');
            $table->date('date')->default(now()->format('Y-m-d')); // Default to today's date
            $table->string('status')->default(0); // present, absent
            $table->time('start_time')->nullable(); // Nullable for 'absent' status
            $table->time('end_time')->nullable(); // Nullable for 'absent' status
            $table->decimal('overtime', 10, 2)->default(0); // Latitude for location tracking
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('attendances');
    }
};
