

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-inner">
            <div class="page-header">
                <h3 class="fw-bold mb-3">Edit Book</h3>
                <ul class="breadcrumbs mb-3">
                    <li class="nav-home">
                        <a href="#">
                            <i class="icon-home"></i>
                        </a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Edit Book</a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Book</a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Edit</a>
                    </li>
                </ul>
            </div>
            <form action="<?php echo e(route('admin.students.update', [$data->id])); ?>" method="post" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">Form Elements</div>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 col-lg-4">
                                        <?php if (isset($component)) { $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-default','data' => ['name' => 'id','label' => 'NIM','type' => 'text','old' => ''.e($data->id).'','disabled' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'id','label' => 'NIM','type' => 'text','old' => ''.e($data->id).'','disabled' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $attributes = $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $component = $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-default','data' => ['name' => 'name','label' => 'Student Name','type' => 'text','old' => ''.e($data->name).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'name','label' => 'Student Name','type' => 'text','old' => ''.e($data->name).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $attributes = $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $component = $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
                                    </div>
                                    <div class="col-md-6 col-lg-4">
                                        <?php if (isset($component)) { $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-default','data' => ['name' => 'email','label' => 'Email','type' => 'email','old' => ''.e($data->email).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'email','label' => 'Email','type' => 'email','old' => ''.e($data->email).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $attributes = $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $component = $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal67ad07a4b593e690d435fee92e6413bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal67ad07a4b593e690d435fee92e6413bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-select','data' => ['name' => 'id_category','label' => 'Student\'s Major','selected' => ''.e($data->id_category).'','options' => $categories->pluck('name', 'id')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'id_category','label' => 'Student\'s Major','selected' => ''.e($data->id_category).'','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categories->pluck('name', 'id'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal67ad07a4b593e690d435fee92e6413bb)): ?>
<?php $attributes = $__attributesOriginal67ad07a4b593e690d435fee92e6413bb; ?>
<?php unset($__attributesOriginal67ad07a4b593e690d435fee92e6413bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal67ad07a4b593e690d435fee92e6413bb)): ?>
<?php $component = $__componentOriginal67ad07a4b593e690d435fee92e6413bb; ?>
<?php unset($__componentOriginal67ad07a4b593e690d435fee92e6413bb); ?>
<?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            </div>
                            <div class="card-action">
                                <button type="submit" class="btn btn-success">Submit</button>
                                <a href="<?php echo e(route('admin.students.index')); ?>" class="btn btn-danger">Cancel</a>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\Laravel\library\resources\views/admin/students/edit.blade.php ENDPATH**/ ?>