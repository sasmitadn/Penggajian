
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-inner">
            <div class="page-header">
                <h3 class="fw-bold mb-3">My Salary</h3>
                <ul class="breadcrumbs mb-3">
                    <li class="nav-home">
                        <a href="#">
                            <i class="icon-home"></i>
                        </a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">My Salary</a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Salary</a>
                    </li>
                </ul>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex align-items-center">
                                <h4 class="card-title">List Salary</h4>
                                
                                    <a href="<?php echo e(route('admin.users.create')); ?>"
                                        class="btn btn-primary ms-auto">
                                        <i class="fa fa-plus"></i>
                                        Add Item
                                    </a>
                                
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="basic-datatables" class="display table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>Tanggal</th>
                                            <th>Total Hari</th>
                                            <th>Total Lembur</th>
                                            <th>Potongan Gaji</th>
                                            <th>Total</th>
                                            <?php if(can_access(['admin.users.edit', 'admin.users.delete'])): ?>
                                                <th>Menu</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if($data->count() > 0): ?>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $detail = $item->detail->where('id_user', Auth::user()->id)->first();
                                                    $amount = $item->detail->where('id_user', Auth::user()->id)->sum('net_salary');
                                                ?>
                                                <tr>
                                                    <td class="text-nowrap"><?php echo e(Date::parse($item->start_date)->format('d M Y') . ' - ' . Date::parse($item->end_date)->format('d M Y')); ?></td>
                                                    <td><?php echo e($detail?->total_days ?? '0'); ?> days</td>
                                                    <td><?php echo e($detail?->total_overtime ?? '0'); ?> hours</td>
                                                    <td><?php echo e('Rp. ' . number_format($detail?->total_deductions ?? 0, 0, '.', ',')); ?></td>
                                                    <td><?php echo e('Rp. ' . number_format($amount, 0, '.', ',')); ?></td>
                                                    <?php if(can_access(['admin.users.edit', 'admin.users.delete'])): ?>
                                                        <td>
                                                            <button class="btn btn-icon btn-clean me-0" type="button"
                                                                id="dropdownMenuButton" data-bs-toggle="dropdown"
                                                                aria-haspopup="true" aria-expanded="false">
                                                                <i class="fas fa-ellipsis-v"></i>
                                                            </button>
                                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                                <?php if(can_access(['admin.users.edit'])): ?>
                                                                    <a class="dropdown-item"
                                                                        href="<?php echo e(route('admin.users.edit', [$item->id])); ?>">View
                                                                        Detail</a>
                                                                <?php endif; ?>
                                                            </div>
                                                        </td>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="6" class="text-center">Data Tidak Ditemukan.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\Laravel\Bima\resources\views/admin/users/salary.blade.php ENDPATH**/ ?>