

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-inner">
            <div class="page-header">
                <h3 class="fw-bold mb-3">Borrow Data</h3>
                <ul class="breadcrumbs mb-3">
                    <li class="nav-home">
                        <a href="#">
                            <i class="icon-home"></i>
                        </a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Borrow Data</a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Borrow</a>
                    </li>
                </ul>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex align-items-center">
                                <h4 class="card-title">Borrow List</h4>
                                <div class="ms-auto">
                                    <?php echo $__env->make('admin.borrows.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                                <?php if(can_access(['admin.borrows.create'])): ?>
                                    <a href="<?php echo e(route('admin.borrows.create')); ?>" class="btn btn-primary ms-2">
                                        <i class="fa fa-plus"></i>
                                        Add Item
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="basic-datatables" class="display table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Student Name</th>
                                            <th>Book Title</th>
                                            <th>Start Date</th>
                                            <th>End Date</th>
                                            <th>Status</th>
                                            <?php if(can_access(['admin.borrows.edit', 'admin.borrows.delete'])): ?>
                                                <th>Menu</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if($data->count() > 0): ?>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($item->id); ?></td>
                                                    <td><?php echo e($item->student ? $item->student->name : ''); ?></td>
                                                    <td><?php echo e($item->book ? $item->book->title : ''); ?></td>
                                                    <td><?php echo e(\Carbon\Carbon::parse($item->start_date)->format('d M Y')); ?></td>
                                                    <td><?php echo e(\Carbon\Carbon::parse($item->end_date)->format('d M Y')); ?></td>
                                                    <td>
                                                        <?php if($item->status == 'done'): ?>
                                                            <span class="badge badge-success"><?php echo e($item->status); ?></span>
                                                        <?php else: ?>
                                                            <span class="badge badge-danger"><?php echo e($item->status); ?></span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <?php if(can_access(['admin.borrows.edit', 'admin.borrows.delete'])): ?>
                                                        <td>
                                                            <button class="btn btn-icon btn-clean me-0" type="button"
                                                                id="dropdownMenuButton" data-bs-toggle="dropdown"
                                                                aria-haspopup="true" aria-expanded="false">
                                                                <i class="fas fa-ellipsis-v"></i>
                                                            </button>
                                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                                <?php if(can_access(['admin.borrows.edit'])): ?>
                                                                    <a class="dropdown-item"
                                                                        href="<?php echo e(route('admin.borrows.edit', [$item->id])); ?>">View
                                                                        Detail</a>
                                                                <?php endif; ?>
                                                                <?php if(can_access(['admin.borrows.delete'])): ?>
                                                                    <form
                                                                        action="<?php echo e(route('admin.borrows.delete', [$item->id])); ?>"
                                                                        method="post">
                                                                        <?php echo method_field('DELETE'); ?>
                                                                        <?php echo csrf_field(); ?>
                                                                        <button type="submit" id="deleteBtn"
                                                                            class="dropdown-item text-danger">Delete</button>
                                                                    </form>
                                                                <?php endif; ?>
                                                            </div>
                                                        </td>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="7" class="text-center">No data available</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\Laravel\library\resources\views/admin/borrows/index.blade.php ENDPATH**/ ?>