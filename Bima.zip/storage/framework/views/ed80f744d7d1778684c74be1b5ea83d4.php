<footer class="footer">
    <div class="container-fluid d-flex justify-content-between">
        
        <div class="copyright">
            <?php echo e(\Carbon\Carbon::now()->format('Y')); ?>, All rights reserved by Bima
        </div>
        
    </div>
</footer>
<?php /**PATH E:\Coding\Laravel\Bima\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>