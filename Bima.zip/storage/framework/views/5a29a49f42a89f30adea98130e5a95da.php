
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-inner">
            <div class="page-header">
                <h3 class="fw-bold mb-3">Book Data</h3>
                <ul class="breadcrumbs mb-3">
                    <li class="nav-home">
                        <a href="#">
                            <i class="icon-home"></i>
                        </a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Book Data</a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Book</a>
                    </li>
                </ul>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex align-items-center">
                                <h4 class="card-title">List Books</h4>
                                <div class="ms-auto">
                                    <?php echo $__env->make('admin.books.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                                <?php if(can_access(['admin.books.create'])): ?>
                                    <a href="<?php echo e(route('admin.books.create')); ?>" class="btn btn-primary ms-2">
                                        <i class="fa fa-plus"></i>
                                        Add Item
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="basic-datatables" class="display table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Title</th>
                                            <th>Description</th>
                                            <th>Author</th>
                                            <th>Publisher</th>
                                            <th>Category</th>
                                            <th>Status</th>
                                            <?php if(can_access(['admin.books.edit', 'admin.books.delete'])): ?>
                                                <th>Menu</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if($data->count() > 0): ?>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($item->id); ?></td>
                                                    <td><?php echo e($item->title); ?></td>
                                                    <td><?php echo e($item->description); ?></td>
                                                    <td><?php echo e($item->author); ?></td>
                                                    <td><?php echo e($item->publisher); ?></td>
                                                    <td><?php echo e($item->category->name); ?></td>
                                                    <td>
                                                        <?php if($item->status == 'available'): ?>
                                                            <span class="badge badge-success">Available</span>
                                                        <?php else: ?>
                                                            <span class="badge badge-danger">Unavailable</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <?php if(can_access(['admin.books.edit', 'admin.books.delete'])): ?>
                                                        <td>
                                                            <button class="btn btn-icon btn-clean me-0" type="button"
                                                                id="dropdownMenuButton" data-bs-toggle="dropdown"
                                                                aria-haspopup="true" aria-expanded="false">
                                                                <i class="fas fa-ellipsis-v"></i>
                                                            </button>
                                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                                <?php if(can_access(['admin.books.edit'])): ?>
                                                                    <a class="dropdown-item"
                                                                        href="<?php echo e(route('admin.books.edit', [$item->id])); ?>">View
                                                                        Detail</a>
                                                                <?php endif; ?>
                                                                <?php if(can_access(['admin.books.delete'])): ?>
                                                                    <form
                                                                        action="<?php echo e(route('admin.books.delete', [$item->id])); ?>"
                                                                        method="post">
                                                                        <?php echo method_field('DELETE'); ?>
                                                                        <?php echo csrf_field(); ?>
                                                                        <button type="submit" id="deleteBtn"
                                                                            class="dropdown-item text-danger">Delete</button>
                                                                    </form>
                                                                <?php endif; ?>
                                                            </div>
                                                        </td>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="8" class="text-center">No data available</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\Laravel\library\resources\views/admin/books/index.blade.php ENDPATH**/ ?>