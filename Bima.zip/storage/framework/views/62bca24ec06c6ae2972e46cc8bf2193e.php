<footer class="footer">
    <div class="container-fluid d-flex justify-content-between">
        
        <div class="copyright">
            <?php echo e(\Carbon\Carbon::now()->format('Y')); ?>, made by
            <a href="https://sasmitadn.com">sasmitadn</a>
        </div>
        
    </div>
</footer>
<?php /**PATH E:\Coding\Laravel\library\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>