<?php if(session('success')): ?>
    <script>
        swal({
            title: "Berhasil!",
            text: "<?php echo e(session('success')); ?>",
            icon: "success",
            buttons: {
                confirm: {
                    text: "Ok",
                    value: true,
                    visible: true,
                    className: "btn btn-success",
                    closeModal: true,
                },
            },
        });
    </script>
<?php endif; ?>

<?php if(session('error')): ?>
    <script>
        swal({
            title: "Oops!",
            text: "<?php echo e(session('error')); ?>",
            icon: "error",
            buttons: {
                confirm: {
                    text: "OK",
                    value: true,
                    visible: true,
                    className: "btn btn-danger",
                    closeModal: true,
                },
            },
        });
    </script>
<?php endif; ?>


<script>
    $('.deleteBtn').on('click', function(e) {
        e.preventDefault();

        swal({
            title: "Yakin ingin menghapus data?",
            text: "Data akan dihapus permanen!",
            icon: "warning",
            buttons: {
                cancel: {
                    text: "Batal",
                    visible: true,
                    className: "btn btn-primary",
                    closeModal: true,
                },
                confirm: {
                    text: "Iya, lanjutkan!",
                    visible: true,
                    className: "btn btn-danger",
                    closeModal: true,
                }
            }
        }).then((willSubmit) => {
            if (willSubmit) {
                $(this).closest('form').submit();
            }
        });
    });

    $('.logoutBtn').on('click', function(e) {
        e.preventDefault();

        swal({
            title: "Keluar Akun?",
            text: "Pastikan Anda mengingat kredensial login!",
            icon: "warning",
            buttons: {
                cancel: {
                    text: "Batal",
                    visible: true,
                    className: "btn btn-primary",
                    closeModal: true,
                },
                confirm: {
                    text: "Iya, Logout!",
                    visible: true,
                    className: "btn btn-danger",
                    closeModal: true,
                }
            }
        }).then((willSubmit) => {
            if (willSubmit) {
                $(this).closest('form').submit();
            }
        });
    });
</script>
<?php /**PATH E:\Coding\Laravel\Bima\resources\views/components/session-alert.blade.php ENDPATH**/ ?>