<!-- Tombol buka filter -->
<button class="btn btn-secondary" data-bs-toggle="offcanvas" data-bs-target="#filterSidebar">
    <i class="fas fa-filter"></i>
</button>

<!-- Offcanvas isi filter -->
<div class="offcanvas offcanvas-end" tabindex="-1" id="filterSidebar">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title">Filter</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
    </div>
    <div class="offcanvas-body">
        <form action="<?php echo e(route('admin.borrows.index')); ?>" method="get" id="filterForm">
            <?php echo csrf_field(); ?>
            <?php if (isset($component)) { $__componentOriginal35ef3cd1fe1b6d61c6447742588d877e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal35ef3cd1fe1b6d61c6447742588d877e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-search','data' => ['class' => 'mb-3','name' => 'id_student','label' => 'Select Student','selected' => ''.e($request->id_student).'','options' => $students->pluck('name', 'id')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-3','name' => 'id_student','label' => 'Select Student','selected' => ''.e($request->id_student).'','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($students->pluck('name', 'id'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal35ef3cd1fe1b6d61c6447742588d877e)): ?>
<?php $attributes = $__attributesOriginal35ef3cd1fe1b6d61c6447742588d877e; ?>
<?php unset($__attributesOriginal35ef3cd1fe1b6d61c6447742588d877e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal35ef3cd1fe1b6d61c6447742588d877e)): ?>
<?php $component = $__componentOriginal35ef3cd1fe1b6d61c6447742588d877e; ?>
<?php unset($__componentOriginal35ef3cd1fe1b6d61c6447742588d877e); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal35ef3cd1fe1b6d61c6447742588d877e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal35ef3cd1fe1b6d61c6447742588d877e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-search','data' => ['class' => 'mb-3','name' => 'id_book','label' => 'Select Book','selected' => ''.e($request->id_book).'','options' => $books->pluck('title', 'id')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-3','name' => 'id_book','label' => 'Select Book','selected' => ''.e($request->id_book).'','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($books->pluck('title', 'id'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal35ef3cd1fe1b6d61c6447742588d877e)): ?>
<?php $attributes = $__attributesOriginal35ef3cd1fe1b6d61c6447742588d877e; ?>
<?php unset($__attributesOriginal35ef3cd1fe1b6d61c6447742588d877e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal35ef3cd1fe1b6d61c6447742588d877e)): ?>
<?php $component = $__componentOriginal35ef3cd1fe1b6d61c6447742588d877e; ?>
<?php unset($__componentOriginal35ef3cd1fe1b6d61c6447742588d877e); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-default','data' => ['name' => 'start_date','old' => ''.e($request->start_date).'','label' => 'Start Date','type' => 'date']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'start_date','old' => ''.e($request->start_date).'','label' => 'Start Date','type' => 'date']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $attributes = $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $component = $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-default','data' => ['name' => 'end_date','old' => ''.e($request->end_date).'','label' => 'End Date','type' => 'date']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'end_date','old' => ''.e($request->end_date).'','label' => 'End Date','type' => 'date']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $attributes = $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $component = $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal73f473ccb713676a1df93cf0881c4a72 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73f473ccb713676a1df93cf0881c4a72 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-radio','data' => ['name' => 'status','label' => 'Status','selected' => ''.e($request->status).'','options' => ['borrowed' => 'Borrowed', 'Late' => 'Late', 'done' => 'Done', '' => 'All']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'status','label' => 'Status','selected' => ''.e($request->status).'','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['borrowed' => 'Borrowed', 'Late' => 'Late', 'done' => 'Done', '' => 'All'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73f473ccb713676a1df93cf0881c4a72)): ?>
<?php $attributes = $__attributesOriginal73f473ccb713676a1df93cf0881c4a72; ?>
<?php unset($__attributesOriginal73f473ccb713676a1df93cf0881c4a72); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73f473ccb713676a1df93cf0881c4a72)): ?>
<?php $component = $__componentOriginal73f473ccb713676a1df93cf0881c4a72; ?>
<?php unset($__componentOriginal73f473ccb713676a1df93cf0881c4a72); ?>
<?php endif; ?>
            <div class="form-group row">
                <div class="col">
                    <button type="button" class="btn btn-outline-primary w-100"
                        onclick="window.location='<?php echo e(route('admin.borrows.index')); ?>'">Clear Filter</button>
                </div>
                <div class="col">
                    <button type="submit" class="btn btn-primary w-100">Apply Filter</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php /**PATH E:\Coding\Laravel\library\resources\views/admin/borrows/filter.blade.php ENDPATH**/ ?>