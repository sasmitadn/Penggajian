<?php if(session('success')): ?>
    <script>
        swal({
            title: "Success!",
            text: "<?php echo e(session('success')); ?>",
            icon: "success",
            buttons: {
                confirm: {
                    text: "Thank You",
                    value: true,
                    visible: true,
                    className: "btn btn-success",
                    closeModal: true,
                },
            },
        });
    </script>
<?php endif; ?>

<?php if(session('error')): ?>
    <script>
        swal({
            title: "Oops!",
            text: "<?php echo e(session('error')); ?>",
            icon: "error",
            buttons: {
                confirm: {
                    text: "OK",
                    value: true,
                    visible: true,
                    className: "btn btn-danger",
                    closeModal: true,
                },
            },
        });
    </script>
<?php endif; ?>


<script>
    $('#deleteBtn').on('click', function(e) {
        e.preventDefault();

        swal({
            title: "Are you sure?",
            text: "Data will be deleted permanently!",
            icon: "warning",
            buttons: {
                cancel: {
                    text: "Cancel",
                    visible: true,
                    className: "btn btn-primary",
                    closeModal: true,
                },
                confirm: {
                    text: "Yes, submit it!",
                    visible: true,
                    className: "btn btn-danger",
                    closeModal: true,
                }
            }
        }).then((willSubmit) => {
            if (willSubmit) {
                $(this).closest('form').submit();
            }
        });
    });

    $('#logoutBtn').on('click', function(e) {
        e.preventDefault();

        swal({
            title: "Logout Account?",
            text: "Make sure you remember your credentials!",
            icon: "warning",
            buttons: {
                cancel: {
                    text: "Cancel",
                    visible: true,
                    className: "btn btn-primary",
                    closeModal: true,
                },
                confirm: {
                    text: "Yes, logout!",
                    visible: true,
                    className: "btn btn-danger",
                    closeModal: true,
                }
            }
        }).then((willSubmit) => {
            if (willSubmit) {
                $(this).closest('form').submit();
            }
        });
    });
</script>
<?php /**PATH E:\Coding\Laravel\library\resources\views/components/session-alert.blade.php ENDPATH**/ ?>