
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-inner">
            <div class="page-header">
                <h3 class="fw-bold mb-3">Absensi</h3>
                <ul class="breadcrumbs mb-3">
                    <li class="nav-home">
                        <a href="#">
                            <i class="icon-home"></i>
                        </a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Absensi</a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Daftar Karyawan</a>
                    </li>
                </ul>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex align-items-center">
                                <h4 class="card-title"><?php echo e(\Carbon\Carbon::parse($date)->format('d M Y')); ?></h4>
                                <div class="ms-auto">
                                    <?php echo $__env->make('admin.attendance.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="basic-datatables" class="display table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>Nama</th>
                                            <th>Absensi</th>
                                            <th>Jam Lembur</th>
                                            <?php if(can_access(['admin.attendances.edit', 'admin.attendances.update'])): ?>
                                                <th>Akhiri Kerja</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if($data->count() > 0): ?>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $attendance = $attendances->firstWhere('id_user', $item->id);
                                                    $work_end = trim($item->category?->work_end ?? '00:00');
                                                    $end_time = trim($attendance?->end_time ?? '00:00');
                                                ?>
                                                <tr>
                                                    <td><?php echo e($item->name); ?></td>
                                                    <td>
                                                        <div class="d-flex justify-content-center">
                                                            <div class="col">
                                                                <button
                                                                    class="btn btn-rounded attendance-btn <?php echo e($attendance?->status == 'present' ? 'btn-primary' : 'btn-outline-primary'); ?> mx-1"
                                                                    data-user="<?php echo e($item->id); ?>"
                                                                    data-date="<?php echo e($date); ?>"
                                                                    data-starttime="<?php echo e($item->category?->work_start); ?>"
                                                                    data-status="present">H</button>
                                                            </div>
                                                            <div class="col">
                                                                <button
                                                                    class="btn btn-rounded attendance-btn <?php echo e($attendance?->status == 'absent' ? 'btn-danger' : 'btn-outline-danger'); ?> mx-1"
                                                                    data-user="<?php echo e($item->id); ?>"
                                                                    data-date="<?php echo e($date); ?>"
                                                                    data-starttime="<?php echo e($item->category?->work_start); ?>"
                                                                    data-status="absent">A</button>
                                                            </div>
                                                            <div class="col"></div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <?php echo e(\Carbon\Carbon::parse($work_end)->format('H:i') . ' - ' . \Carbon\Carbon::parse($attendance?->end_time ?? '00:00')->format('H:i')); ?>

                                                        =
                                                        <?php echo e($attendance?->overtime ? $attendance->overtime . ' jam' : '0 jam'); ?>

                                                    </td>
                                                    <?php if(can_access(['admin.attendances.edit', 'admin.attendances.update'])): ?>
                                                        <td>
                                                            <div class="d-flex flex-row align-items-center">
                                                                <div class="form-group">
                                                                    <input type="time" name="end_time" id=""
                                                                        placeholder="Input overtime" class="form-control"
                                                                        value="<?php echo e(Date::parse($item->category->work_end)->format('H:i') ?? ''); ?>">
                                                                </div>
                                                                <button
                                                                    class="btn btn-primary btn-end-work <?php echo e($attendance != null ? '' : 'disabled'); ?>"
                                                                    data-id="<?php echo e($attendance?->id ? $attendance?->id : '0'); ?>"
                                                                    data-user="<?php echo e($item->id); ?>"
                                                                    style="max-height: 48px">Akhiri Kerja</button>
                                                            </div>
                                                        </td>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="6" class="text-center">Data Tidak Ditemukan.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                                <?php echo e($data->links('vendor.pagination.bootstrap-5')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $('.btn-end-work').click(function() {
            if ($(this).hasClass('disabled')) return;

            const id = $(this).data('id');
            const end_time = $(this).closest('tr').find('input[type="time"]').val();
            const routeUpdate = '<?php echo e(route('admin.attendances.update', ':id')); ?>';
            const url = routeUpdate.replace(':id', id);

            $.ajax({
                url: url, // bikin route ini
                method: 'PUT',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    end_time,
                    date: '<?php echo e($date); ?>'
                },
                success: function(res) {
                    console.log('Updated!', res);
                    location.reload(); // atau update overtime di DOM kalau mau lebih smooth
                },
                error: function(err) {
                    console.error(err);
                }
            });
        });


        $('.attendance-btn').click(function() {
            const id_user = $(this).data('user');
            const status = $(this).data('status');
            const date = $(this).data('date');
            const starttime = $(this).data('starttime');

            $.ajax({
                url: '<?php echo e(route('admin.attendances.store')); ?>',
                method: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    id_user,
                    status,
                    date,
                    start_time: starttime
                },
                success: function(res) {
                    console.log('Updated!', starttime);
                    location.reload();
                    // $('.attendance-btn[data-user="' + id_user + '"]').each(function() {
                    //     const status = $(this).data('status');
                    //     if (status === 'present') {
                    //         $(this).removeClass('btn-primary').addClass('btn-outline-primary');
                    //     } else if (status === 'absent') {
                    //         $(this).removeClass('btn-danger').addClass('btn-outline-danger');
                    //     }
                    // });

                    // // Aktifin tombol yang diklik
                    // const clickedBtn = $('.attendance-btn[data-user="' + id_user + '"][data-status="' +
                    //     status + '"]');
                    // if (status === 'present') {
                    //     clickedBtn.removeClass('btn-outline-primary').addClass('btn-primary');
                    // } else if (status === 'absent') {
                    //     clickedBtn.removeClass('btn-outline-danger').addClass('btn-danger');
                    // }

                    // $('.btn[data-user="' + id_user + '"].btn-end-work').removeClass('disabled');
                },
                error: function(err) {
                    console.error(err);
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\Laravel\Bima\resources\views/admin/attendance/index.blade.php ENDPATH**/ ?>