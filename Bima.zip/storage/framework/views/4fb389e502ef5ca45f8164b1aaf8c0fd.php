<!-- resources/views/components/form-group.blade.php -->
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['name', 'label', 'type' => 'text', 'old' => '', 'disabled' => false]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['name', 'label', 'type' => 'text', 'old' => '', 'disabled' => false]); ?>
<?php foreach (array_filter((['name', 'label', 'type' => 'text', 'old' => '', 'disabled' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php if($disabled): ?>
    <div class="form-group">
        <label for="<?php echo e($name); ?>"><?php echo e($label); ?></label>
        <textarea type="<?php echo e($type); ?>" class="form-control" id="<?php echo e($name); ?>" name="<?php echo e($name); ?>"
            placeholder="Enter <?php echo e($label); ?>" rows="5" disabled><?php echo e(old($name, $old)); ?></textarea>
        <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
<?php else: ?>
    <div class="form-group">
        <label for="<?php echo e($name); ?>"><?php echo e($label); ?></label>
        <textarea type="<?php echo e($type); ?>" class="form-control" id="<?php echo e($name); ?>" name="<?php echo e($name); ?>"
            placeholder="Enter <?php echo e($label); ?>" rows="5"><?php echo e(old($name, $old)); ?></textarea>
        <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
<?php endif; ?>

<!-- resources/views/components/form-group.blade.php -->
<?php /**PATH E:\Coding\Laravel\library\resources\views/components/form-textarea.blade.php ENDPATH**/ ?>