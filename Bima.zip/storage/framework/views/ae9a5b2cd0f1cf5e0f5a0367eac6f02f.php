<div class="sidebar" data-background-color="dark">
    <div class="sidebar-logo">
        <!-- Logo Header -->
        <div class="logo-header" data-background-color="dark">
            <a href="index.html" class="logo">
                
                <h1 class="fs-2 text-white">Tap Library</h1>
            </a>
            <div class="nav-toggle">
                <button class="btn btn-toggle toggle-sidebar">
                    <i class="gg-menu-right"></i>
                </button>
                <button class="btn btn-toggle sidenav-toggler">
                    <i class="gg-menu-left"></i>
                </button>
            </div>
            <button class="topbar-toggler more">
                <i class="gg-more-vertical-alt"></i>
            </button>
        </div>
        <!-- End Logo Header -->
    </div>
    <div class="sidebar-wrapper scrollbar scrollbar-inner">
        <div class="sidebar-content">
            <ul class="nav nav-secondary">
                <?php if(can_access(['admin.dashboard'])): ?>
                    <li class="nav-item <?php echo e(is_active_route(['admin.dashboard'])); ?>">
                        <a href="<?php echo e(route('admin.dashboard')); ?>" class="collapsed" aria-expanded="false">
                            <i class="fas fa-th-large"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(can_access(['admin.borrows.index'])): ?>
                    <li
                        class="nav-item <?php echo e(is_active_route(['admin.borrows.index', 'admin.borrows.create', 'admin.borrows.edit'])); ?>">
                        <a href="<?php echo e(route('admin.borrows.index')); ?>">
                            <i class="fas fa-folder-open"></i>
                            <p>Peminjaman</p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(can_access(['admin.users.admin.index', 'admin.users.staff.index'])): ?>
                    <li
                        class="nav-item <?php echo e(is_active_route(['admin.users.admin.index', 'admin.users.admin.create', 'admin.users.admin.edit', 'admin.users.staff.index', 'admin.users.staff.create', 'admin.users.staff.edit'])); ?>">
                        <a data-bs-toggle="collapse" href="#userAccess">
                            <i class="fas fa-users"></i>
                            <p>User Access</p>
                            <span class="caret"></span>
                        </a>
                        <div class="collapse" id="userAccess">
                            <ul class="nav nav-collapse">
                                <?php if(can_access(['admin.users.admin.index'])): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.users.admin.index', ['admin'])); ?>">
                                            <span class="sub-item">Admin</span>
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if(can_access(['admin.users.staff.index'])): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.users.staff.index', ['staff'])); ?>">
                                            <span class="sub-item">Staff / Office</span>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </li>
                <?php endif; ?>
                <?php if(can_access(['admin.books.index', 'admin.students.index'])): ?>
                    <li class="nav-section">
                        <span class="sidebar-mini-icon">
                            <i class="fa fa-ellipsis-h"></i>
                        </span>
                        <h4 class="text-section">Database</h4>
                    </li>
                    <?php if(can_access(['admin.books.index'])): ?>
                        <li
                            class="nav-item <?php echo e(is_active_route(['admin.books.index', 'admin.books.create', 'admin.books.edit'])); ?>">
                            <a href="<?php echo e(route('admin.books.index')); ?>">
                                <i class="fas fa-book"></i>
                                <p>Books</p>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if(can_access(['admin.students.index'])): ?>
                        <li
                            class="nav-item <?php echo e(is_active_route(['admin.students.index', 'admin.students.create', 'admin.students.edit'])); ?>">
                            <a href="<?php echo e(route('admin.students.index')); ?>">
                                <i class="fas fa-graduation-cap"></i>
                                <p>Students</p>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if(can_access(['admin.book_category.index', 'admin.major_category.index'])): ?>
                        <li
                            class="nav-item <?php echo e(is_active_route(['admin.book_category.index', 'admin.book_category.create', 'admin.book_category.edit', 'admin.major_category.index', 'admin.major_category.create', 'admin.major_category.edit'])); ?>">
                            <a data-bs-toggle="collapse" href="#category">
                                <i class="fas fa-database"></i>
                                <p>Category</p>
                                <span class="caret"></span>
                            </a>
                            <div class="collapse" id="category">
                                <ul class="nav nav-collapse subnav">
                                    <?php if(can_access(['admin.major_category.index'])): ?>
                                        <li>
                                            <a href="<?php echo e(route('admin.major_category.index', ['major_category'])); ?>">
                                                <span class="sub-item">Major</span>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if(can_access(['admin.book_category.index'])): ?>
                                        <li>
                                            <a href="<?php echo e(route('admin.book_category.index', ['book_category'])); ?>">
                                                <span class="sub-item">Book</span>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>

            </ul>
        </div>
    </div>
</div>
<?php /**PATH E:\Coding\Laravel\library\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>