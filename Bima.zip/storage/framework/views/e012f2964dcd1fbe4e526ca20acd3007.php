<!-- Tombol buka filter -->
<button class="btn btn-secondary" data-bs-toggle="offcanvas" data-bs-target="#filterSidebar">
    <i class="fas fa-filter"></i>
</button>

<!-- Offcanvas isi filter -->
<div class="offcanvas offcanvas-end" tabindex="-1" id="filterSidebar">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title">Filter</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
    </div>
    <div class="offcanvas-body">
        <form action="<?php echo e(route('admin.payrolls.index')); ?>" method="get" id="filterForm">
            <?php echo csrf_field(); ?>
            <?php if (isset($component)) { $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-default','data' => ['name' => 'start_date','old' => ''.e($request->start_date).'','label' => 'Tanggal Mulai','type' => 'date']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'start_date','old' => ''.e($request->start_date).'','label' => 'Tanggal Mulai','type' => 'date']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $attributes = $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $component = $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-default','data' => ['name' => 'end_date','old' => ''.e($request->end_date).'','label' => 'Tanggal Akhir','type' => 'date']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'end_date','old' => ''.e($request->end_date).'','label' => 'Tanggal Akhir','type' => 'date']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $attributes = $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $component = $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
            <div class="form-group row">
                <div class="col">
                    <button type="button" class="btn btn-outline-primary w-100"
                        onclick="window.location='<?php echo e(route('admin.payrolls.index')); ?>'">Hapus Filter</button>
                </div>
                <div class="col">
                    <button type="submit" class="btn btn-primary w-100">Terapkan Filter</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php /**PATH E:\Coding\Laravel\Bima\resources\views/admin/payrolls/filter.blade.php ENDPATH**/ ?>