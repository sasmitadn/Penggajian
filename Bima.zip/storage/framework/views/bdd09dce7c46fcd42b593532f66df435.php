

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-inner">
            <div class="page-header">
                <h3 class="fw-bold mb-3">Edit Book</h3>
                <ul class="breadcrumbs mb-3">
                    <li class="nav-home">
                        <a href="#">
                            <i class="icon-home"></i>
                        </a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Edit Book</a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Book</a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Edit</a>
                    </li>
                </ul>
            </div>
            <form action="<?php echo e(route('admin.books.update', [$data->id])); ?>" method="post" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">Form Elements</div>
                            </div>
                            <div class="card-body">
                                <div class="card-body">
                                    <div class="row">
                                    <div class="col-md-6 col-lg-4">
                                        <?php if (isset($component)) { $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-default','data' => ['name' => 'id','label' => 'Unique Code','type' => 'text','old' => ''.e($data->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'id','label' => 'Unique Code','type' => 'text','old' => ''.e($data->id).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $attributes = $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $component = $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-default','data' => ['name' => 'title','label' => 'Title','type' => 'text','old' => ''.e($data->title).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'title','label' => 'Title','type' => 'text','old' => ''.e($data->title).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $attributes = $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $component = $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal67ad07a4b593e690d435fee92e6413bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal67ad07a4b593e690d435fee92e6413bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-select','data' => ['name' => 'id_category','label' => 'Book Category','selected' => ''.e($data->id_category).'','options' => $categories->pluck('name', 'id')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'id_category','label' => 'Book Category','selected' => ''.e($data->id_category).'','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categories->pluck('name', 'id'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal67ad07a4b593e690d435fee92e6413bb)): ?>
<?php $attributes = $__attributesOriginal67ad07a4b593e690d435fee92e6413bb; ?>
<?php unset($__attributesOriginal67ad07a4b593e690d435fee92e6413bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal67ad07a4b593e690d435fee92e6413bb)): ?>
<?php $component = $__componentOriginal67ad07a4b593e690d435fee92e6413bb; ?>
<?php unset($__componentOriginal67ad07a4b593e690d435fee92e6413bb); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginalcc0154580828f80bdab5d7fe416ed74a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcc0154580828f80bdab5d7fe416ed74a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-textarea','data' => ['name' => 'description','label' => 'Description','type' => 'text','old' => ''.e($data->description).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'description','label' => 'Description','type' => 'text','old' => ''.e($data->description).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcc0154580828f80bdab5d7fe416ed74a)): ?>
<?php $attributes = $__attributesOriginalcc0154580828f80bdab5d7fe416ed74a; ?>
<?php unset($__attributesOriginalcc0154580828f80bdab5d7fe416ed74a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcc0154580828f80bdab5d7fe416ed74a)): ?>
<?php $component = $__componentOriginalcc0154580828f80bdab5d7fe416ed74a; ?>
<?php unset($__componentOriginalcc0154580828f80bdab5d7fe416ed74a); ?>
<?php endif; ?>
                                    </div>
                                    <div class="col-md-6 col-lg-4">
                                        <?php if (isset($component)) { $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-default','data' => ['name' => 'author','label' => 'Author','type' => 'text','old' => ''.e($data->author).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'author','label' => 'Author','type' => 'text','old' => ''.e($data->author).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $attributes = $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $component = $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-default','data' => ['name' => 'publisher','label' => 'Publisher','type' => 'text','old' => ''.e($data->publisher).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'publisher','label' => 'Publisher','type' => 'text','old' => ''.e($data->publisher).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $attributes = $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $component = $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-default','data' => ['name' => 'release_year','label' => 'Release Year','type' => 'number','old' => ''.e($data->release_year).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'release_year','label' => 'Release Year','type' => 'number','old' => ''.e($data->release_year).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $attributes = $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $component = $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-default','data' => ['name' => 'isbn','label' => 'ISBN (optional)','type' => 'text','old' => ''.e($data->isbn).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'isbn','label' => 'ISBN (optional)','type' => 'text','old' => ''.e($data->isbn).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $attributes = $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $component = $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal73f473ccb713676a1df93cf0881c4a72 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73f473ccb713676a1df93cf0881c4a72 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-radio','data' => ['name' => 'status','label' => 'Status','selected' => ''.e($data->status).'','options' => ['available' => 'Available', 'unavailable' => 'Unavailable']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'status','label' => 'Status','selected' => ''.e($data->status).'','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['available' => 'Available', 'unavailable' => 'Unavailable'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73f473ccb713676a1df93cf0881c4a72)): ?>
<?php $attributes = $__attributesOriginal73f473ccb713676a1df93cf0881c4a72; ?>
<?php unset($__attributesOriginal73f473ccb713676a1df93cf0881c4a72); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73f473ccb713676a1df93cf0881c4a72)): ?>
<?php $component = $__componentOriginal73f473ccb713676a1df93cf0881c4a72; ?>
<?php unset($__componentOriginal73f473ccb713676a1df93cf0881c4a72); ?>
<?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            </div>
                            <div class="card-action">
                                <button type="submit" class="btn btn-success">Submit</button>
                                <a href="<?php echo e(route('admin.books.index')); ?>" class="btn btn-danger">Cancel</a>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\Laravel\library\resources\views/admin/books/edit.blade.php ENDPATH**/ ?>