

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-inner">
            <div class="page-header">
                <h3 class="fw-bold mb-3">Tambah Jabatan</h3>
                <ul class="breadcrumbs mb-3">
                    <li class="nav-home">
                        <a href="#">
                            <i class="icon-home"></i>
                        </a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Jabatan</a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Tambah</a>
                    </li>
                </ul>
            </div>
            <form action="<?php echo e(route('admin.' . $menu . '.store', [$menu])); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">Formulir</div>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 col-lg-4">
                                        <?php if (isset($component)) { $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-default','data' => ['name' => 'name','label' => 'Nama','type' => 'text']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'name','label' => 'Nama','type' => 'text']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $attributes = $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $component = $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal73f473ccb713676a1df93cf0881c4a72 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73f473ccb713676a1df93cf0881c4a72 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-radio','data' => ['name' => 'status','label' => 'Status','selected' => 'active','options' => ['active' => 'Aktif', 'inactive' => 'Tidak Aktif']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'status','label' => 'Status','selected' => 'active','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['active' => 'Aktif', 'inactive' => 'Tidak Aktif'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73f473ccb713676a1df93cf0881c4a72)): ?>
<?php $attributes = $__attributesOriginal73f473ccb713676a1df93cf0881c4a72; ?>
<?php unset($__attributesOriginal73f473ccb713676a1df93cf0881c4a72); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73f473ccb713676a1df93cf0881c4a72)): ?>
<?php $component = $__componentOriginal73f473ccb713676a1df93cf0881c4a72; ?>
<?php unset($__componentOriginal73f473ccb713676a1df93cf0881c4a72); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal73f473ccb713676a1df93cf0881c4a72 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73f473ccb713676a1df93cf0881c4a72 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-radio','data' => ['name' => 'is_paid','label' => 'Kategori','selected' => '1','options' => ['1' => 'Dibayar', '0' => 'Tidak Dibayar']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'is_paid','label' => 'Kategori','selected' => '1','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['1' => 'Dibayar', '0' => 'Tidak Dibayar'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73f473ccb713676a1df93cf0881c4a72)): ?>
<?php $attributes = $__attributesOriginal73f473ccb713676a1df93cf0881c4a72; ?>
<?php unset($__attributesOriginal73f473ccb713676a1df93cf0881c4a72); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73f473ccb713676a1df93cf0881c4a72)): ?>
<?php $component = $__componentOriginal73f473ccb713676a1df93cf0881c4a72; ?>
<?php unset($__componentOriginal73f473ccb713676a1df93cf0881c4a72); ?>
<?php endif; ?>
                                    </div>
                                    <div class="col-md-6 col-lg-4 hiddenLayout">
                                        <?php if (isset($component)) { $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-default','data' => ['name' => 'price_daily','label' => 'Gaji Harian','type' => 'number']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'price_daily','label' => 'Gaji Harian','type' => 'number']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $attributes = $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $component = $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-default','data' => ['name' => 'price_overtime','label' => 'Gaji Lembur','type' => 'number']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'price_overtime','label' => 'Gaji Lembur','type' => 'number']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $attributes = $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $component = $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
                                    </div>
                                    <div class="col-md-6 col-lg-4 hiddenLayout">
                                        <?php if (isset($component)) { $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-default','data' => ['name' => 'work_start','label' => 'Jam Kerja Mulai','type' => 'time']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'work_start','label' => 'Jam Kerja Mulai','type' => 'time']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $attributes = $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $component = $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-default','data' => ['name' => 'work_end','label' => 'Jam Kerja Berakhir','type' => 'time']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'work_end','label' => 'Jam Kerja Berakhir','type' => 'time']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $attributes = $__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__attributesOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd)): ?>
<?php $component = $__componentOriginal16d28ef94b8d24df84fcb0975377ffcd; ?>
<?php unset($__componentOriginal16d28ef94b8d24df84fcb0975377ffcd); ?>
<?php endif; ?>
                                    </div>
                                </div>
                                <div>
                                    <div class="card-header">
                                        <div class="card-title">Perizinan</div>
                                    </div>
                                    <div class="card-body">
                                        <input type="checkbox" id="checkAll"> Pilih Semua
                                        <table class="table table-responsive table-bordered mt-3">
                                            <thead>
                                                <tr>
                                                    <th scope="col">Fitur</th>
                                                    <th scope="col">Tambah</th>
                                                    <th scope="col">Lihat</th>
                                                    <th scope="col">Perbarui</th>
                                                    <th scope="col">Hapus</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = Config::get('role'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature => $actions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($feature); ?></td>
                                                        <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action => $routes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <td>
                                                                <?php if(count($routes) != 0): ?>
                                                                    <input type="checkbox"
                                                                        value="<?php echo e(json_encode($routes)); ?>" name="role[]"
                                                                        class="accessCheckbox"
                                                                        <?php echo e(in_array(json_encode($routes), old('role', [])) ? 'checked' : ''); ?>>
                                                                <?php endif; ?>
                                                            </td>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="card-action">
                                    <button type="submit" class="btn btn-success">Kirim</button>
                                    <a href="<?php echo e(route('admin.' . $menu . '.index', [$menu])); ?>"
                                        class="btn btn-danger">Batal</a>
                                </div>
                            </div>
                        </div>
                    </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const radios = document.querySelectorAll('input[name="is_paid"]');
            const hiddenLayouts = document.getElementsByClassName('hiddenLayout');

            function toggleHiddenLayout(show) {
                for (let i = 0; i < hiddenLayouts.length; i++) {
                    hiddenLayouts[i].style.display = show ? 'block' : 'none';
                }
            }

            radios.forEach(radio => {
                radio.addEventListener('click', function() {
                    toggleHiddenLayout(this.value === '1');
                });
            });

            const checked = document.querySelector('input[name="is_paid"]:checked');
            toggleHiddenLayout(checked && checked.value === '1');


            document.getElementById('checkAll').addEventListener('change', function() {
                var checkboxes = document.querySelectorAll('.accessCheckbox');
                checkboxes.forEach(function(checkbox) {
                    checkbox.checked = document.getElementById('checkAll').checked;
                });
            });
            document.getElementById('topBar').classList.add('d-none')
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\Laravel\Bima\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>