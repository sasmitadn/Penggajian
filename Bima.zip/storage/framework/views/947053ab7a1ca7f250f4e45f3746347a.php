

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-inner">
            <div class="page-header">
                <h3 class="fw-bold mb-3">Detail Gaji Karyawan</h3>
                <ul class="breadcrumbs mb-3">
                    <li class="nav-home">
                        <a href="#">
                            <i class="icon-home"></i>
                        </a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Detail Gaji Karyawan</a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Gaji Karyawan</a>
                    </li>
                </ul>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex align-items-center">
                                <h4 class="card-title">
                                    <?php echo e(Date::parse($start_date)->format('d M Y') . ' - ' . Date::parse($end_date)->format('d M Y')); ?>

                                </h4>
                                <div class="ms-auto">
                                    <?php echo $__env->make('admin.payrolls.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="basic-datatables" class="display table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>Nama</th>
                                            <th>Total Hari</th>
                                            <th>Total Lembur</th>
                                            <th>Gaji Pokok</th>
                                            <th>Total Lembur</th>
                                            <th>Total Pengurangan</th>
                                            <th>Total Gaji</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if($data->count() > 0): ?>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($item->user->name); ?></td>
                                                    <td><?php echo e(number_format($item->total_days, 0) . ' days'); ?></td>
                                                    <td><?php echo e($item->total_overtime . ' hours'); ?></td>
                                                    <td><?php echo e('Rp. ' . number_format($item->amount_salary, 0, '.', ',')); ?></td>
                                                    <td><?php echo e('Rp. ' . number_format($item->amount_overtime, 0, '.', ',')); ?>

                                                    </td>
                                                    <td><?php echo e('Rp. ' . number_format($item->amount_deductions, 0, '.', ',')); ?>

                                                    </td>
                                                    <td><?php echo e('Rp. ' . number_format($item->net_salary, 0, '.', ',')); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="7" class="text-center">Data Tidak Ditemukan.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\Laravel\Bima\resources\views/admin/payrolls/detail.blade.php ENDPATH**/ ?>