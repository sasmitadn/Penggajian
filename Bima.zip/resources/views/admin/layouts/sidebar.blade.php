<div class="sidebar" data-background-color="dark">
    <div class="sidebar-logo">
        <!-- Logo Header -->
        <div class="logo-header" data-background-color="dark">
            <a href="index.html" class="logo">
                {{-- <img src="{{ asset('img/kaiadmin/logo_light.svg') }}" alt="navbar brand" class="navbar-brand"
                    height="20" /> --}}
                <h1 class="fs-2 text-white">Penggajian</h1>
            </a>
            <div class="nav-toggle">
                <button class="btn btn-toggle toggle-sidebar">
                    <i class="gg-menu-right"></i>
                </button>
                <button class="btn btn-toggle sidenav-toggler">
                    <i class="gg-menu-left"></i>
                </button>
            </div>
            <button class="topbar-toggler more">
                <i class="gg-more-vertical-alt"></i>
            </button>
        </div>
        <!-- End Logo Header -->
    </div>
    <div class="sidebar-wrapper scrollbar scrollbar-inner">
        <div class="sidebar-content">
            <ul class="nav nav-secondary">
                @if (can_access(['admin.dashboard']))
                    <li class="nav-item {{ is_active_route(['admin.dashboard']) }}">
                        <a href="{{ route('admin.dashboard') }}" class="collapsed" aria-expanded="false">
                            <i class="fas fa-th-large"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                @endif
                @if (can_access(['admin.attendances.index']))
                    <li class="nav-item {{ is_active_route(['admin.attendances.index']) }}">
                        <a href="{{ route('admin.attendances.index') }}">
                            <i class="fas fa-laptop"></i>
                            <p>Absensi</p>
                        </a>
                    </li>
                @endif
                @if (can_access(['admin.attendances.index', 'admin.cash_advances.index', 'admin.payrolls.index', 'admin.salary']))
                    <li class="nav-section">
                        <span class="sidebar-mini-icon">
                            <i class="fa fa-ellipsis-h"></i>
                        </span>
                        <h4 class="text-section">Keuangan</h4>
                    </li>
                    @if (can_access(['admin.salary']))
                        <li class="nav-item {{ is_active_route(['admin.salary']) }}">
                            <a href="{{ route('admin.salary') }}">
                                <i class="fas fa-wallet"></i>
                                <p>Gaji Saya</p>
                            </a>
                        </li>
                    @endif
                    @if (can_access(['admin.my_cash_advances.index']))
                        <li class="nav-item {{ is_active_route(['admin.my_cash_advances.create','admin.my_cash_advances.index','admin.my_cash_advances.edit','admin.my_cash_advances.create']) }}">
                            <a href="{{ route('admin.my_cash_advances.index') }}">
                                <i class="fas fa-money-bill"></i>
                                <p>Ajukan Pinjaman</p>
                            </a>
                        </li>
                    @endif
                    @if (can_access(['admin.cash_advances.index']))
                        <li class="nav-item {{ is_active_route(['admin.cash_advances.index','admin.cash_advances.create','admin.cash_advances.edit']) }}">
                            <a href="{{ route('admin.cash_advances.index') }}">
                                <i class="fas fa-money-bill"></i>
                                <p>Pinjaman Karyawan</p>
                            </a>
                        </li>
                    @endif
                    @if (can_access(['admin.payrolls.index']))
                        <li class="nav-item {{ is_active_route(['admin.payrolls.index','admin.payrolls.create','admin.payrolls.detail']) }}">
                            <a href="{{ route('admin.payrolls.index') }}">
                                <i class="fas fa-dollar-sign"></i>
                                <p>Daftar Gaji</p>
                            </a>
                        </li>
                    @endif
                @endif
                @if (can_access(['admin.users.index', 'admin.job_category.index']))
                    <li class="nav-section">
                        <span class="sidebar-mini-icon">
                            <i class="fa fa-ellipsis-h"></i>
                        </span>
                        <h4 class="text-section">Kelola Karyawan</h4>
                    </li>
                    @if (can_access(['admin.users.index']))
                        <li class="nav-item {{ is_active_route(['admin.users.index','admin.users.create','admin.users.edit']) }}">
                            <a href="{{ route('admin.users.index') }}">
                                <i class="fas fa-users"></i>
                                <p>Daftar User</p>
                            </a>
                        </li>
                    @endif
                    @if (can_access(['admin.job_category.index']))
                        <li class="nav-item {{ is_active_route(['admin.job_category.index','admin.job_category.create','admin.job_category.edit']) }}">
                            <a href="{{ route('admin.job_category.index', ['job_category']) }}">
                                <i class="fas fa-folder-open"></i>
                                <p>Jabatan</p>
                            </a>
                        </li>
                    @endif
                @endif

            </ul>
        </div>
    </div>
</div>
