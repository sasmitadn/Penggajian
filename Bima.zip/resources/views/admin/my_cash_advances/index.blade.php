@extends('admin.layouts.app')
@section('content')
    <div class="container">
        <div class="page-inner">
            <div class="page-header">
                <h3 class="fw-bold mb-3">Data Pinjaman</h3>
                <ul class="breadcrumbs mb-3">
                    <li class="nav-home">
                        <a href="#">
                            <i class="icon-home"></i>
                        </a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Data Pinjaman</a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Pinjaman</a>
                    </li>
                </ul>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex align-items-center">
                                <h4 class="card-title">Daftar Pinjaman</h4>
                                <div class="ms-auto">
                                    @include('admin.my_cash_advances.filter')
                                </div>
                                <a href="{{ route('admin.my_cash_advances.create') }}" class="btn btn-primary ms-2">
                                    <i class="fa fa-plus"></i>
                                    Tambah Data
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="basic-datatables" class="display table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>Deskripsi</th>
                                            <th>Total</th>
                                            <th>Tanggal</th>
                                            <th>Status Approval</th>
                                            <th>Status Terbayar</th>
                                            <th>Waktu Terbayar</th>
                                            <th>Menu</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if ($data->count() > 0)
                                            @foreach ($data as $item)
                                                <tr>
                                                    <td>{{ $item->description }}</td>
                                                    <td>{{ 'Rp. ' . number_format($item->amount, 0, '.', ',') }}</td>
                                                    <td>{{ $item->date }}</td>
                                                    <td>
                                                        @if ($item->status == 'approved')
                                                            <span class="badge badge-success">Approved</span>
                                                        @elseif ($item->status == 'pending')
                                                            <span class="badge badge-warning">Pending</span>
                                                        @else
                                                            <span class="badge badge-danger">Rejected</span>
                                                        @endif
                                                    </td>
                                                    <td>
                                                        @if ($item->payroll != null)
                                                            <span class="badge badge-success">Paid</span>
                                                        @else
                                                            <span class="badge badge-danger">Unpaid</span>
                                                        @endif
                                                    </td>
                                                    <td>{{ $item->payroll ? \Carbon\Carbon::parse($item->payroll?->end_date)->format('d M Y') : 'not yet' }}</td>
                                                    <td>
                                                        @if ($item->status == 'approved')
                                                            <button class="btn btn-icon btn-clean me-0" type="button">
                                                                <i class="fas fa-lock"
                                                                    title="Approved data cannot be edited."></i>
                                                            </button>
                                                        @else
                                                            <button class="btn btn-icon btn-clean me-0" type="button"
                                                                id="dropdownMenuButton" data-bs-toggle="dropdown"
                                                                aria-haspopup="true" aria-expanded="false">
                                                                <i class="fas fa-ellipsis-v"></i>
                                                            </button>
                                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                                @if (can_access(['admin.my_cash_advances.edit', 'admin.my_cash_advances.update']))
                                                                    <a class="dropdown-item"
                                                                        href="{{ route('admin.my_cash_advances.edit', [$item->id]) }}">View
                                                                        Detail</a>
                                                                @endif
                                                                @if (can_access(['admin.my_cash_advances.delete']))
                                                                    <form
                                                                        action="{{ route('admin.my_cash_advances.delete', [$item->id]) }}"
                                                                        method="post">
                                                                        @method('DELETE')
                                                                        @csrf
                                                                        <button type="submit"
                                                                            class="dropdown-item text-danger deleteBtn">Delete</button>
                                                                    </form>
                                                                @endif
                                                            </div>
                                                        @endif
                                                    </td>
                                                </tr>
                                            @endforeach
                                        @else
                                            <tr>
                                                <td colspan="6" class="text-center">No data available</td>
                                            </tr>
                                        @endif
                                    </tbody>
                                </table>
                                {{ $data->links('vendor.pagination.bootstrap-5') }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
