@extends('admin.layouts.app')
@section('content')
    <div class="container">
        <div class="page-inner">
            <div class="page-header">
                <h3 class="fw-bold mb-3">Absensi</h3>
                <ul class="breadcrumbs mb-3">
                    <li class="nav-home">
                        <a href="#">
                            <i class="icon-home"></i>
                        </a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Absensi</a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Daftar Karyawan</a>
                    </li>
                </ul>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex align-items-center">
                                <h4 class="card-title">{{ \Carbon\Carbon::parse($date)->format('d M Y') }}</h4>
                                <div class="ms-auto">
                                    @include('admin.attendance.filter')
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="basic-datatables" class="display table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>Nama</th>
                                            <th>Absensi</th>
                                            <th>Jam Lembur</th>
                                            @if (can_access(['admin.attendances.edit', 'admin.attendances.update']))
                                                <th>Akhiri Kerja</th>
                                            @endif
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if ($data->count() > 0)
                                            @foreach ($data as $item)
                                                @php
                                                    $attendance = $attendances->firstWhere('id_user', $item->id);
                                                    $work_end = trim($item->category?->work_end ?? '00:00');
                                                    $end_time = trim($attendance?->end_time ?? '00:00');
                                                @endphp
                                                <tr>
                                                    <td>{{ $item->name }}</td>
                                                    <td>
                                                        <div class="d-flex justify-content-center">
                                                            <div class="col">
                                                                <button
                                                                    class="btn btn-rounded attendance-btn {{ $attendance?->status == 'present' ? 'btn-primary' : 'btn-outline-primary' }} mx-1"
                                                                    data-user="{{ $item->id }}"
                                                                    data-date="{{ $date }}"
                                                                    data-starttime="{{ $item->category?->work_start }}"
                                                                    data-status="present">H</button>
                                                            </div>
                                                            <div class="col">
                                                                <button
                                                                    class="btn btn-rounded attendance-btn {{ $attendance?->status == 'absent' ? 'btn-danger' : 'btn-outline-danger' }} mx-1"
                                                                    data-user="{{ $item->id }}"
                                                                    data-date="{{ $date }}"
                                                                    data-starttime="{{ $item->category?->work_start }}"
                                                                    data-status="absent">A</button>
                                                            </div>
                                                            <div class="col"></div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        {{ \Carbon\Carbon::parse($work_end)->format('H:i') . ' - ' . \Carbon\Carbon::parse($attendance?->end_time ?? '00:00')->format('H:i') }}
                                                        =
                                                        {{ $attendance?->overtime ? $attendance->overtime . ' jam' : '0 jam' }}
                                                    </td>
                                                    @if (can_access(['admin.attendances.edit', 'admin.attendances.update']))
                                                        <td>
                                                            <div class="d-flex flex-row align-items-center">
                                                                <div class="form-group">
                                                                    <input type="time" name="end_time" id=""
                                                                        placeholder="Input overtime" class="form-control"
                                                                        value="{{ Date::parse($item->category->work_end)->format('H:i') ?? '' }}">
                                                                </div>
                                                                <button
                                                                    class="btn btn-primary btn-end-work {{ $attendance != null ? '' : 'disabled' }}"
                                                                    data-id="{{ $attendance?->id ? $attendance?->id : '0' }}"
                                                                    data-user="{{ $item->id }}"
                                                                    style="max-height: 48px">Akhiri Kerja</button>
                                                            </div>
                                                        </td>
                                                    @endif
                                                </tr>
                                            @endforeach
                                        @else
                                            <tr>
                                                <td colspan="6" class="text-center">Data Tidak Ditemukan.</td>
                                            </tr>
                                        @endif
                                    </tbody>
                                </table>
                                {{ $data->links('vendor.pagination.bootstrap-5') }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('js')
    <script>
        $('.btn-end-work').click(function() {
            if ($(this).hasClass('disabled')) return;

            const id = $(this).data('id');
            const end_time = $(this).closest('tr').find('input[type="time"]').val();
            const routeUpdate = '{{ route('admin.attendances.update', ':id') }}';
            const url = routeUpdate.replace(':id', id);

            $.ajax({
                url: url, // bikin route ini
                method: 'PUT',
                data: {
                    _token: '{{ csrf_token() }}',
                    end_time,
                    date: '{{ $date }}'
                },
                success: function(res) {
                    console.log('Updated!', res);
                    location.reload(); // atau update overtime di DOM kalau mau lebih smooth
                },
                error: function(err) {
                    console.error(err);
                }
            });
        });


        $('.attendance-btn').click(function() {
            const id_user = $(this).data('user');
            const status = $(this).data('status');
            const date = $(this).data('date');
            const starttime = $(this).data('starttime');

            $.ajax({
                url: '{{ route('admin.attendances.store') }}',
                method: 'POST',
                data: {
                    _token: '{{ csrf_token() }}',
                    id_user,
                    status,
                    date,
                    start_time: starttime
                },
                success: function(res) {
                    console.log('Updated!', starttime);
                    location.reload();
                    // $('.attendance-btn[data-user="' + id_user + '"]').each(function() {
                    //     const status = $(this).data('status');
                    //     if (status === 'present') {
                    //         $(this).removeClass('btn-primary').addClass('btn-outline-primary');
                    //     } else if (status === 'absent') {
                    //         $(this).removeClass('btn-danger').addClass('btn-outline-danger');
                    //     }
                    // });

                    // // Aktifin tombol yang diklik
                    // const clickedBtn = $('.attendance-btn[data-user="' + id_user + '"][data-status="' +
                    //     status + '"]');
                    // if (status === 'present') {
                    //     clickedBtn.removeClass('btn-outline-primary').addClass('btn-primary');
                    // } else if (status === 'absent') {
                    //     clickedBtn.removeClass('btn-outline-danger').addClass('btn-danger');
                    // }

                    // $('.btn[data-user="' + id_user + '"].btn-end-work').removeClass('disabled');
                },
                error: function(err) {
                    console.error(err);
                }
            });
        });
    </script>
@endpush
