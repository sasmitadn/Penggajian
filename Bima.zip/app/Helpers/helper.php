<?php

use Illuminate\Support\Facades\Route;

if (!function_exists('user_can_access')) {
    function can_access(array $routeNames): bool {
        $userRoutes = json_decode(auth()->user()->category?->role ?? '[]', true);
        return !empty(array_intersect($routeNames, $userRoutes)); // get the same route
    }
}

if (!function_exists('is_active_route')) {
    function is_active_route(array $routeNames, string $class = 'active'): string
    {
        return in_array(Route::currentRouteName(), $routeNames) ? $class : '';
    }
}