<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Attendance;
use App\Models\User;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;

class AttendanceController extends Controller
{
    public function index(Request $request)
    {
        $query = User::query();
        if ($request->filled('name')) {
            $query->where('name', 'like', '%' . $request->name . '%');
        }
        if ($request->filled('status')) {
            if ($request->status == 'not_set') {
                $query->whereDoesntHave('attendances', function ($query) use ($request) {
                    $query->whereDate('date', $request->date ?? now()->format('Y-m-d'));
                });
            } else {
                $query->whereHas('attendances', function ($query) use ($request) {
                    $query->whereDate('date', $request->date ?? now()->format('Y-m-d'))
                        ->where('status', $request->status);
                });
            }
        }
        $data = $query->whereHas('category', function ($query) {
            $query->where('is_paid', 1);
        })->with('category')->orderBy('name', 'asc')->paginate(Config::get('setting.pagination.per_page', 10));
        $date = $request->date ?? now();
        $date = Carbon::parse($date)->format('Y-m-d');
        $attendances = Attendance::where('date', $date)->with(['user', 'user.category'])->get();
        return view('admin.attendance.index', compact('data', 'attendances', 'request', 'date'));
    }

    public function create()
    {
        // Logic to show form for creating attendance record
        return view('admin.attendance.create');
    }

    public function edit($id)
    {
        // Logic to show form for editing attendance record
        return view('admin.attendance.edit', compact('id'));
    }

    public function store(Request $request)
    {
        $date = $request->date ? $request->date : now()->format('Y-m-d');

        $data = Attendance::firstOrNew([
            'id_user' => $request->id_user,
            'date' => $date,
        ]);
        $data->id_user = $request->id_user;
        $data->date = $date;
        $data->status = $request->status;
        $data->start_time = $request->start_time;
        $data->save();
        return response()->json($data);
    }

    public function update(Request $request, $id)
    {
        $data = Attendance::findOrFail($id);

        if ($data) {
            $user = User::with('category')->where('id', $data->id_user)->first();
            $data->end_time = $request->end_time;
            $start = Carbon::parse($user->category->work_end);
            $end = Carbon::parse($request->end_time);
            $minutes = $start->diffInMinutes($end, false); // hasil bisa negatif kalau end < start
            $overtime = $minutes > 0 ? $minutes / 60 : 0;
            $data->overtime = $overtime;
            $data->save();
            return response()->json(['success' => true]);
        }

        return response()->json(['error' => 'Not found'], 404);
    }

    public function destroy($id)
    {
        // Logic to delete an attendance record
    }
}
