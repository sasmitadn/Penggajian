<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\CashAdvance;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;

class MyCashAdvancesController extends Controller
{
    public function index(Request $request)
    {
        $query = CashAdvance::query();
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        $data = $query->with(['user','payroll'])->orderBy('created_at', 'desc')->paginate(Config::get('setting.pagination.per_page', 10));
        $users = User::where('status', 'active')->get();
        return view('admin.my_cash_advances.index', compact('data', 'request', 'users'));
    }

    public function create()
    {
        $users = User::where('status', 'active')->get();
        return view('admin.my_cash_advances.create', compact('users'));
    }

    public function edit($id)
    {
        $data = CashAdvance::findOrFail($id);
        $users = User::where('status', 'active')->get();
        return view('admin.my_cash_advances.edit', compact('data', 'users'));
    }
    public function destroy($id)
    {
        $model = CashAdvance::findOrFail($id);
        $model->delete();
        return back()->with('success', 'Data berhasil dihapus.');
    }
    public function store(Request $request)
    {
        $request->validate([
            'amount' => 'required',
            'description' => 'required|max:255',
            'date' => 'required',
        ]);
        $model = new CashAdvance();
        $model->id_user = Auth::id();
        $model->amount = $request->amount;
        $model->description = $request->description;
        $model->date = $request->date;
        $model->save();
        return redirect()->route('admin.my_cash_advances.index')->with('success', 'Data berhasil dibuat.');
    }
    public function update(Request $request, $id)
    {
        $request->validate([
            'amount' => 'required|numeric',
            'description' => 'required|string',
            'date' => 'required|date',
        ]);
        $model = CashAdvance::findOrFail($id);
        $model->amount = $request->amount;
        $model->description = $request->description;
        $model->date = $request->date;
        $model->save();
        return back()->with('success', 'Data berhasil diperbarui.');
    }
}
