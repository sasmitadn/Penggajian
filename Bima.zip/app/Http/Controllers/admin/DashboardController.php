<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Attendance;
use App\Models\CashAdvance;
use App\Models\Category;
use App\Models\Payroll;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class DashboardController extends Controller
{
    public function index()
    {
        $totalEmployees = User::whereHas('category', function ($q) {
            $q->where('is_paid', 1);
        })->count();
        $totalActiveToday = Attendance::where([
            ['date', now()->format('Y-m-d')],
            ['status', 'present']
        ])->count();
        $totalAbsentToday = $totalEmployees - $totalActiveToday;
        $pendingCashAdvances = CashAdvance::where('status', 'pending')->count();

        // multiple bar chart
        $lastDate = Attendance::orderBy('date', 'desc')->value('date') ?? now()->format('Y-m-d');
        // Ambil 12 tanggal ke belakang (mundur)
        $dates = collect(range(0, 11))->map(function ($i) use ($lastDate) {
            return Carbon::parse($lastDate)->subDays(11 - $i)->format('Y-m-d');
        });
        // Siapkan data
        $labels = [];
        $presents = [];
        $absents = [];
        $notSets = [];
        foreach ($dates as $date) {
            $present = Attendance::where('date', $date)->where('status', 'present')->count();
            $absent = Attendance::where('date', $date)->where('status', 'absent')->count();
            $notSet = $present != null || $absent != null ? $totalEmployees - ($present + $absent) : 0;
            $labels[] = Carbon::parse($date)->format('d M');
            $presents[] = $present;
            $absents[] = $absent;
            $notSets[] = $notSet;
        }

        // latest salary
        $data = Payroll::orderBy('created_at', 'desc')->limit(4)->get()->reverse()->values();

        $labels1 = [];
        $salary1 = [];
        $totals1 = 0;
        $labels1[] = 'Salary';
        $salary1[] = 0;
        foreach ($data as $payroll) {
            $label = Carbon::parse($payroll->start_date)->format('d M Y') . ' - ' .
                Carbon::parse($payroll->end_date)->format('d M Y');
            $labels1[] = $label;

            $sum = DB::table('payroll_details')
                ->where('id_payroll', $payroll->id)
                ->sum('net_salary');

            $salary1[] = (float) $sum;
            $totals1 += $sum;
        }
        $labels1[] = 'Salary';
        $salary1[] = 0;


        // top user
        $topUsers = User::select('users.*', DB::raw('COUNT(attendances.id) as total_present'))
            ->join('attendances', 'users.id', '=', 'attendances.id_user')
            ->where('attendances.status', 'present')
            ->where('attendances.date', '>=', Carbon::now()->subDays(30))
            ->groupBy('users.id')
            ->orderByDesc('total_present')
            ->limit(5)
            ->get();

        
        // job category
        $categories = Category::withCount(['users' => function ($query) {
            $query->where([
                ['status', 'active']
            ]);
        }])->where('is_paid', 1)->get();

        return view('admin.dashboard', compact('totalEmployees', 'totalActiveToday', 'totalAbsentToday', 'pendingCashAdvances', 'labels', 'presents', 'absents', 'notSets', 'labels1', 'salary1', 'totals1','topUsers','categories'));
    }

    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        if (Auth::attempt($request->only('email', 'password'))) {
            return redirect()->route('admin.dashboard');
        }

        return back()->withErrors([
            'email' => 'The provided credentials do not match our records.',
        ]);
    }

    public function editProfile()
    {
        $user = Auth::user();
        $data = User::findOrFail($user->id);
        return view('admin.users.profile', compact('data'));
    }

    public function updateProfile(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email,' . $id,
            'address' => 'nullable|string',
            'phone' => 'nullable|string|max:15|unique:users,phone,' . $id
        ]);
        $user = Auth::user();
        $model = User::findOrFail($user->id);
        $model->name = $request->name;
        $model->email = $request->email;
        if (filled($request->password)) {
            $request->validate([
                'password' => 'required|string|min:8|confirmed',
            ]);
            $model->password = Hash::make($request->password);
        }
        $model->address = $request->address;
        $model->phone = $request->phone;
        $model->save();
        return back()->with('success', 'Profile updated successfully.');
    }

    public function salary()
    {
        $user = Auth::user();
        $data = Payroll::with('detail')->get();
        return view('admin.users.salary', compact('data'));
    }
}
