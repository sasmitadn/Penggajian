<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\CashAdvance;
use App\Models\Category;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Str;

class CashAdvanceController extends Controller
{
    public function index(Request $request)
    {
        $query = CashAdvance::query();
        if ($request->filled('id_user')) {
            $query->where('id_user', $request->id_category);
        }
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        $data = $query->with('user')->paginate(Config::get('setting.pagination.per_page', 10));
        $users = User::where('status', 'active')->get();
        return view('admin.cash_advances.index', compact('data','request','users'));
    }

    public function create()
    {
        $users = User::where('status', 'active')->get();
        return view('admin.cash_advances.create', compact('users'));
    }

    public function edit($id)
    {
        $data = CashAdvance::findOrFail($id);
        $users = User::where('status', 'active')->get();
        return view('admin.cash_advances.edit', compact('data', 'users'));
    }
    public function destroy($id)
    {
        $model = CashAdvance::findOrFail($id);
        $model->delete();
        return back()->with('success', 'Data berhasil dihapus.');
    }
    public function store(Request $request)
    {
        $request->validate([
            'id_user' => 'required|string|exists:users,id',
            'amount' => 'required|numeric',
            'description' => 'required|string',
            'date' => 'required|date',
            'status' => 'required|string|in:pending,approved,rejected',
        ]);
        $model = new CashAdvance();
        $model->id_user = $request->id_user;
        $model->amount = $request->amount;
        $model->description = $request->description;
        $model->date = $request->date;
        $model->status = $request->status;
        $model->save();
        return redirect()->route('admin.cash_advances.index')->with('success', 'Data berhasil dibuat.');
    }
    public function update(Request $request, $id)
    {
        $request->validate([
            'status' => 'required|string|in:pending,approved,rejected',
        ]);
        $model = CashAdvance::findOrFail($id);
        $model->status = $request->status;
        $model->save();
        return redirect()->route('admin.cash_advances.index')->with('success', 'Data berhasil diperbarui.');
    }
}
