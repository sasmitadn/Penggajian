<?php

return [
    'pagination' => [
        'per_page' => 50,
    ],
];