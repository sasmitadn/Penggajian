<?php

return [
    'Dashboard' => [
        'create' => [],
        'read' => ['admin.dashboard'],
        'update' => [],
        'delete' => []
    ],
    'Absensi' => [
        'create' => [],
        'read' => ['admin.attendances.index'],
        'update' => ['admin.attendances.edit','admin.attendances.update'],
        'delete' => []
    ],
    'Gaji Saya' => [
        'create' => [],
        'read' => ['admin.salary'],
        'update' => [],
        'delete' => []
    ],
    'Ajukan Pinjaman' => [
        'create' => ['admin.my_cash_advances.create','admin.my_cash_advances.store'],
        'read' => ['admin.my_cash_advances.index'],
        'update' => ['admin.my_cash_advances.edit','admin.my_cash_advances.update'],
        'delete' => ['admin.my_cash_advances.delete']
    ],
    'Pinjaman Karyawan' => [
        'create' => ['admin.cash_advances.create','admin.cash_advances.store'],
        'read' => ['admin.cash_advances.index'],
        'update' => ['admin.cash_advances.edit','admin.cash_advances.update'],
        'delete' => ['admin.cash_advances.delete']
    ],
    'Daftar Gaji' => [
        'create' => ['admin.payrolls.create','admin.payrolls.store'],
        'read' => ['admin.payrolls.index', 'admin.payrolls.detail'],
        'update' => [],
        'delete' => ['admin.payrolls.delete']
    ],
    'Daftar User' => [
        'create' => ['admin.users.create','admin.users.store'],
        'read' => ['admin.users.index'],
        'update' => ['admin.users.edit','admin.users.update'],
        'delete' => ['admin.users.delete']
    ],
    'Jabatan' => [
        'create' => ['admin.job_category.create','admin.job_category.store'],
        'read' => ['admin.job_category.index'],
        'update' => ['admin.job_category.edit','admin.job_category.update'],
        'delete' => ['admin.job_category.delete']
    ]
];